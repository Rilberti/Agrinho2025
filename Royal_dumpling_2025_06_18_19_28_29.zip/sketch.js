// ====================================================================
// Variáveis Globais do Jogo
// ====================================================================
let estadoJogo = 'menu'; // Estados: 'menu', 'jogando', 'final'
let pontos = 0;          // Pontuação do jogador
const tempoTotalJogo = 180; // Duração de 3 minutos em segundos
let timerJogoInicio;     // Tempo de início do jogo

// Canteiros da Horta
let canteiros = [];
const NUM_CANTEIROS = 4; // Teremos 4 canteiros
let canteiroLargura, canteiroAltura;
let canteiroStartX, canteiroStartY;

// Imagens do jogo
let bgHorta;
let imgSoloCanteiro;
let imgSemente, imgBroto, imgPlantaJovem, imgPlantaMadura;
let imgRegador, imgJoaninha, imgPraga, imgCestaColheita;
let imgVovoNormal, imgVovoPreocupada;
let iconPlantar, iconRegar, iconProteger, iconColher;

// Variáveis de Feedback e Vovó
let feedbackMessage = '';
let feedbackColor;
let feedbackTimer = 0;
const FEEDBACK_DURATION = 120; // Duração da mensagem em frames (aprox. 2 segundos)
let vovoFalando = false;
let vovoMensagem = '';
let vovoTimer = 0;
const VOVO_FALA_DURATION = 180; // Duração da fala da Vovó em frames

// ====================================================================
// Função preload() - Carrega recursos
// ====================================================================
function preload() {
    try {
        bgHorta = loadImage('assets/background_horta.png');
        imgSoloCanteiro = loadImage('assets/solo_canteiro.png');
        imgSemente = loadImage('assets/semente_generica.png');
        imgBroto = loadImage('assets/broto_generico.png');
        imgPlantaJovem = loadImage('assets/planta_jovem.png');
        imgPlantaMadura = loadImage('assets/planta_madura.png');
        imgRegador = loadImage('assets/regador.png');
        imgJoaninha = loadImage('assets/joaninha.png');
        imgPraga = loadImage('assets/praga.png');
        imgCestaColheita = loadImage('assets/cesta_colheita.png');
        imgVovoNormal = loadImage('assets/vovo_normal.png');
        imgVovoPreocupada = loadImage('assets/vovo_preocupada.png');
        iconPlantar = loadImage('assets/icon_plantar.png');
        iconRegar = loadImage('assets/icon_regar.png');
        iconProteger = loadImage('assets/icon_proteger.png');
        iconColher = loadImage('assets/icon_colher.png');

        console.log("Todas as imagens carregadas com sucesso!");
    } catch (error) {
        console.error("ERRO: Falha ao carregar um ou mais recursos. Verifique se os arquivos estão na pasta 'assets' e se os nomes estão corretos (case-sensitive).", error);
    }
}

// ====================================================================
// Função setup() - Configurações iniciais
// ====================================================================
function setup() {
    createCanvas(1000, 700); // Um pouco maior para a horta
    imageMode(CENTER);
    textAlign(CENTER, CENTER);
    textSize(24);

    // Configurações dos canteiros
    canteiroLargura = 200;
    canteiroAltura = 150;
    // Centraliza os canteiros na parte inferior da tela
    canteiroStartX = width / 2 - (canteiroLargura * NUM_CANTEIROS / 2) - ((NUM_CANTEIROS - 1) * 30 / 2); // Ajuste para espaçamento
    canteiroStartY = height * 0.55; // Posição vertical para os canteiros

    // Inicializa os canteiros
    for (let i = 0; i < NUM_CANTEIROS; i++) {
        canteiros.push(new Canteiro(canteiroStartX + i * (canteiroLargura + 30), canteiroStartY, canteiroLargura, canteiroAltura, i));
    }

    reiniciarJogo();
}

// ====================================================================
// Função draw() - Loop principal
// ====================================================================
function draw() {
    image(bgHorta, width / 2, height / 2, width, height); // Desenha o fundo da horta

    if (estadoJogo === 'menu') {
        desenhaMenu();
    } else if (estadoJogo === 'jogando') {
        desenhaJogo();
        atualizaJogo();
    } else if (estadoJogo === 'final') {
        desenhaFinal();
    }
}

// ====================================================================
// Funções de Desenho das Telas
// ====================================================================

function desenhaMenu() {
    fill(0, 80, 0, 200); // Verde escuro semitransparente
    rect(width / 2, height / 2, 700, 500, 20);

    fill(255);
    textSize(50);
    text("Agrinho: A Horta da Vovó", width / 2, height / 2 - 150);
    textSize(30);
    text("Ajude a Vovó a ter uma horta saudável!", width / 2, height / 2 - 60);
    textSize(22);
    text("Plante, regue, proteja e colha os vegetais orgânicos.", width / 2, height / 2 + 10);
    text("Mostre que você é um craque na agricultura familiar!", width / 2, height / 2 + 50);
    textSize(28);
    fill(255, 255, 0);
    text("Clique para começar!", width / 2, height / 2 + 120);
}

function desenhaJogo() {
    // Desenha os canteiros
    for (let canteiro of canteiros) {
        canteiro.desenha();
    }

    desenhaVovo();
    desenhaBotoesAcao();
    desenhaPainelSuperior(); // Pontuação e Tempo
    desenhaFeedback();
}

function desenhaVovo() {
    let vovoImg = imgVovoNormal;
    if (vovoFalando) {
        vovoImg = imgVovoPreocupada; // A Vovó fica preocupada quando tem um aviso
    }
    image(vovoImg, width - 150, 150, 200, 250); // Posição da Vovó

    if (vovoFalando) {
        fill(255, 255, 200, map(vovoTimer, 0, VOVO_FALA_DURATION, 0, 255)); // Balão de fala
        rect(width - 300, 100, 250, 80, 10);
        fill(0, 0, 0, map(vovoTimer, 0, VOVO_FALA_DURATION, 0, 255)); // Texto do balão
        textSize(18);
        text(vovoMensagem, width - 300, 100, 240, 70); // Texto dentro do balão
    }
}

function desenhaBotoesAcao() {
    const btnLargura = 90;
    const btnAltura = 90;
    const gap = 20;
    const startX = width / 2 - (btnLargura * 2 + gap * 1.5); // Para 4 botões centrados
    const btnY = height - 70;

    let botoes = [
        { img: iconPlantar, acao: 'plantar' },
        { img: iconRegar, acao: 'regar' },
        { img: iconProteger, acao: 'proteger' },
        { img: iconColher, acao: 'colher' }
    ];

    for (let i = 0; i < botoes.length; i++) {
        let btnX = startX + i * (btnLargura + gap) + btnLargura / 2;
        image(botoes[i].img, btnX, btnY, btnLargura, btnAltura);

        // Feedback visual ao passar o mouse
        if (dist(mouseX, mouseY, btnX, btnY) < btnLargura / 2) {
            fill(0, 200, 0, 80); // Verde transparente
            ellipse(btnX, btnY, btnLargura + 10, btnAltura + 10);
        }
    }
}

function desenhaPainelSuperior() {
    fill(0, 0, 0, 150); // Fundo preto semitransparente
    rect(width / 2, 40, width - 40, 60, 10); // Painel superior

    fill(255);
    textSize(22);
    // Pontuação
    text(`Pontos: ${pontos}`, 120, 40);

    // Tempo
    let tempoDecorrido = (millis() - timerJogoInicio) / 1000;
    let tempoRestante = Math.ceil(tempoTotalJogo - tempoDecorrido);
    text(`Tempo: ${max(0, tempoRestante)}s`, width - 120, 40);

    // Dica para interagir com canteiros
    fill(255, 255, 0); // Amarelo
    textSize(18);
    text("Clique nos canteiros para interagir com as plantas!", width / 2, 40);
}

function desenhaFeedback() {
    if (feedbackTimer > 0) {
        fill(feedbackColor.levels[0], feedbackColor.levels[1], feedbackColor.levels[2], map(feedbackTimer, 0, FEEDBACK_DURATION, 0, 255));
        textSize(30);
        text(feedbackMessage, width / 2, height / 2 - 200);
    }
}

function desenhaFinal() {
    fill(0, 80, 0, 200);
    rect(width / 2, height / 2, 700, 500, 20);

    fill(255);
    textSize(50);
    text("Fim da Colheita da Vovó!", width / 2, height / 2 - 150);
    textSize(36);
    text(`Sua Pontuação Final: ${pontos}`, width / 2, height / 2 - 50);

    textSize(24);
    if (pontos >= 500) {
        text("Parabéns! Você é um super(a) ajudante da Vovó!", width / 2, height / 2 + 20);
    } else if (pontos >= 200) {
        text("Bom trabalho! A Vovó está orgulhosa!", width / 2, height / 2 + 20);
    } else {
        text("A Vovó precisa de mais ajuda. Tente novamente!", width / 2, height / 2 + 20);
    }
    
    textSize(28);
    fill(255, 255, 0);
    text("Clique para jogar novamente", width / 2, height / 2 + 150);
}

// ====================================================================
// Funções de Lógica do Jogo
// ====================================================================

function atualizaJogo() {
    // Atualização do tempo de jogo
    let tempoDecorrido = (millis() - timerJogoInicio) / 1000;
    if (tempoDecorrido >= tempoTotalJogo) {
        estadoJogo = 'final';
        return;
    }

    // Atualiza feedback e fala da Vovó
    if (feedbackTimer > 0) feedbackTimer--;
    if (vovoTimer > 0) vovoTimer--;
    else vovoFalando = false;

    // Atualiza cada canteiro
    for (let canteiro of canteiros) {
        canteiro.atualiza();
    }
}

// ====================================================================
// Função mousePressed() - Interações do Jogador
// ====================================================================
function mousePressed() {
    if (estadoJogo === 'menu') {
        estadoJogo = 'jogando';
        timerJogoInicio = millis();
        reiniciarJogo();
    } else if (estadoJogo === 'final') {
        estadoJogo = 'menu';
        pontos = 0;
    } else if (estadoJogo === 'jogando') {
        // Verifica cliques nos botões de ação
        const btnLargura = 90;
        const btnAltura = 90;
        const gap = 20;
        const startX = width / 2 - (btnLargura * 2 + gap * 1.5);
        const btnY = height - 70;

        let botoes = [
            { acao: 'plantar', x: startX + btnLargura / 2 },
            { acao: 'regar', x: startX + btnLargura * 1.5 + gap + btnLargura / 2 },
            { acao: 'proteger', x: startX + btnLargura * 2.5 + gap * 2 + btnLargura / 2 },
            { acao: 'colher', x: startX + btnLargura * 3.5 + gap * 3 + btnLargura / 2 }
        ];

        for (let btn of botoes) {
            if (dist(mouseX, mouseY, btn.x, btn.y) < btnLargura / 2) {
                // Ativar o modo de ação para o canteiro
                for (let canteiro of canteiros) {
                    if (canteiro.isMouseOver()) {
                        canteiro.executarAcao(btn.acao);
                        return; // Ação executada, sai do loop
                    }
                }
                // Se clicou no botão mas não no canteiro, avisa
                falaVovo("Clique também no canteiro para aplicar a ação!", color(255, 150, 0));
                return;
            }
        }
    }
}

// ====================================================================
// Classes do Jogo
// ====================================================================

// Classe Canteiro (representa um espaço na horta)
class Canteiro {
    constructor(x, y, largura, altura, id) {
        this.x = x;
        this.y = y;
        this.largura = largura;
        this.altura = altura;
        this.id = id; // Identificador único do canteiro
        this.planta = null; // Começa sem planta
    }

    desenha() {
        image(imgSoloCanteiro, this.x, this.y, this.largura, this.altura); // Desenha o solo
        if (this.planta) {
            this.planta.desenha(this.x, this.y, this.largura * 0.8, this.altura * 0.8); // Desenha a planta no canteiro
        }
        // Desenha borda se o mouse estiver em cima
        if (this.isMouseOver() && estadoJogo === 'jogando') {
            noFill();
            stroke(255, 255, 0, 150); // Borda amarela transparente
            strokeWeight(3);
            rect(this.x, this.y, this.largura, this.altura, 5);
            noStroke();
        }
    }

    atualiza() {
        if (this.planta) {
            this.planta.atualiza();
            // Avisos da Vovó baseados na planta
            if (this.planta.estadoAgua < 20 && !this.planta.avisadoAgua) {
                falaVovo("Oh, meu bem! A plantinha precisa de água!", color(255, 100, 0));
                this.planta.avisadoAgua = true;
            }
            if (this.planta.temPragas && !this.planta.avisadoPraga) {
                falaVovo("Olha só, umas pragas nas minhas verdinhas!", color(255, 0, 0));
                this.planta.avisadoPraga = true;
            }
        }
    }

    isMouseOver() {
        // Verifica se o mouse está sobre o canteiro
        return mouseX > this.x - this.largura / 2 && mouseX < this.x + this.largura / 2 &&
               mouseY > this.y - this.altura / 2 && mouseY < this.y + this.altura / 2;
    }

    executarAcao(acao) {
        if (acao === 'plantar') {
            if (!this.planta) {
                this.planta = new Planta();
                exibirFeedback("Semente plantada! Cuide bem dela!", color(0, 150, 0));
                pontos += 5;
            } else {
                exibirFeedback("Este canteiro já tem uma planta!", color(255, 100, 0));
                pontos = max(0, pontos - 1);
            }
        } else if (this.planta) {
            if (acao === 'regar') {
                if (this.planta.estadoAgua < 100) {
                    this.planta.estadoAgua = 100;
                    pontos += 10;
                    exibirFeedback("Planta regada! Agora vai crescer!", color(0, 150, 0));
                    this.planta.avisadoAgua = false; // Resetar aviso
                } else {
                    exibirFeedback("A planta não precisa de água agora.", color(255, 100, 0));
                }
            } else if (acao === 'proteger') {
                if (this.planta.temPragas) {
                    this.planta.temPragas = false;
                    pontos += 20; // Mais pontos por combater pragas
                    exibirFeedback("Pragas removidas! Plantinha feliz!", color(0, 180, 0));
                    this.planta.avisadoPraga = false; // Resetar aviso
                } else {
                    exibirFeedback("Não há pragas para proteger agora.", color(255, 100, 0));
                }
            } else if (acao === 'colher') {
                if (this.planta.estagio === 'madura') {
                    pontos += 50; // Pontos por colheita
                    exibirFeedback("Vegetal colhido! Que delícia!", color(0, 200, 0));
                    this.planta = null; // Remove a planta do canteiro
                } else {
                    exibirFeedback("A planta ainda não está madura para colher!", color(200, 0, 0));
                    pontos = max(0, pontos - 5);
                }
            }
        } else { // Não tem planta no canteiro selecionado
            exibirFeedback("Plante algo antes de interagir!", color(255, 100, 0));
        }
    }
}

// Classe Planta (representa um vegetal no canteiro)
class Planta {
    constructor() {
        this.estagio = 'semente'; // 'semente', 'broto', 'jovem', 'madura'
        this.estadoAgua = 100; // Nível de água (0-100)
        this.temPragas = false;
        this.crescimentoTimer = 0; // Contagem de frames para o crescimento
        this.avisadoAgua = false; // Para Vovó não repetir aviso
        this.avisadoPraga = false;
    }

    desenha(x, y, largura, altura) {
        let currentImg;
        let scaleFactor = 1;
        switch (this.estagio) {
            case 'semente': currentImg = imgSemente; scaleFactor = 0.3; break;
            case 'broto': currentImg = imgBroto; scaleFactor = 0.5; break;
            case 'jovem': currentImg = imgPlantaJovem; scaleFactor = 0.7; break;
            case 'madura': currentImg = imgPlantaMadura; scaleFactor = 1.0; break;
        }
        image(currentImg, x, y - altura * 0.1, largura * scaleFactor, altura * scaleFactor); // Ajusta Y para ficar "no solo"

        // Desenha pragas se houver
        if (this.temPragas) {
            image(imgPraga, x + largura * 0.3, y - altura * 0.2, 50, 50); // Praga na planta
        }

        // Indicador de sede
        if (this.estadoAgua < 40) {
            fill(0, 0, 200, map(this.estadoAgua, 0, 40, 255, 0)); // Azul transparente
            text("💧", x, y + altura / 2 - 20); // Icone de gota d'água
        }
    }

    atualiza() {
        // Consumo de água
        this.estadoAgua = max(0, this.estadoAgua - 0.2); // Diminui lentamente

        // Crescimento da planta (só cresce se tiver água e sem pragas)
        if (this.estadoAgua > 30 && !this.temPragas) {
            this.crescimentoTimer++;

            if (this.estagio === 'semente' && this.crescimentoTimer >= 300) { // 5 segundos
                this.estagio = 'broto';
                this.crescimentoTimer = 0;
                exibirFeedback("A semente brotou!", color(0, 150, 0));
            } else if (this.estagio === 'broto' && this.crescimentoTimer >= 480) { // 8 segundos
                this.estagio = 'jovem';
                this.crescimentoTimer = 0;
                exibirFeedback("A planta está crescendo!", color(0, 150, 0));
            } else if (this.estagio === 'jovem' && this.crescimentoTimer >= 600) { // 10 segundos
                this.estagio = 'madura';
                this.crescimentoTimer = 0;
                exibirFeedback("Planta madura! Hora de colher!", color(0, 180, 0));
            }
        } else {
            // Se a planta estiver sem água ou com pragas, ela não cresce e pode murchar
            if (this.estadoAgua === 0 && frameCount % 60 === 0) {
                pontos = max(0, pontos - 3); // Penalidade por planta murcha
                exibirFeedback("A planta está murchando de sede!", color(200, 0, 0));
            }
            if (this.temPragas && frameCount % 60 === 0) {
                pontos = max(0, pontos - 5); // Penalidade por pragas comendo
                exibirFeedback("As pragas estão atacando a planta!", color(200, 0, 0));
            }
        }

        // Surgimento de pragas (chance aleatória, mais chance se a horta for negligenciada)
        if (!this.temPragas && this.estagio !== 'semente' && random() < 0.0005 * (100 - this.estadoAgua) / 100) { // Maior chance com pouca água
            this.temPragas = true;
            falaVovo("Ai, ai! Apareceram umas pragas nas minhas plantas!", color(255, 0, 0));
        }
    }
}

// ====================================================================
// Funções Auxiliares
// ====================================================================

function reiniciarJogo() {
    pontos = 0;
    timerJogoInicio = millis();
    for (let canteiro of canteiros) {
        canteiro.planta = null; // Limpa todas as plantas
    }
    feedbackMessage = '';
    feedbackTimer = 0;
    vovoFalando = false;
}

/**
 * Exibe uma mensagem de feedback temporária na tela.
 * @param {string} msg A mensagem a ser exibida.
 * @param {p5.Color} [c=color(0, 100, 0)] A cor do texto da mensagem.
 */
function exibirFeedback(msg, c = color(0, 100, 0)) {
    feedbackMessage = msg;
    feedbackColor = c;
    feedbackTimer = FEEDBACK_DURATION;
}

/**
 * Faz a Vovó "falar" uma mensagem.
 * @param {string} msg A mensagem que a Vovó vai dizer.
 * @param {p5.Color} [c=color(0, 100, 0)] A cor da mensagem de feedback no balão (opcional).
 */
function falaVovo(msg, c = color(0, 100, 0)) {
    vovoMensagem = msg;
    vovoFalando = true;
    vovoTimer = VOVO_FALA_DURATION;
    // Também exibe no centro da tela para maior visibilidade
    exibirFeedback(msg, c); 
}

// Permite que mousePressed também funcione para toques em dispositivos móveis
function touchStarted() {
  return false; 
}